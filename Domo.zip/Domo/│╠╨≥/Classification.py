# encoding: utf-8

import pandas as pd
import cPickle as pickle
from sklearn import tree
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.ensemble import GradientBoostingClassifier



index = [5,6,12,20,21,23,24,27,34,37,43,56,64,71,72,73,75,77,80,82,84,93,108,111,112,118,122,124,125,131,132,133,139,142,143,148,152,159,162,172,180]

def train(x_txt, y_txt):
    train_df = pd.read_csv(x_txt, header=None)
    train_df = train_df[index]

    y_appetency = pd.read_csv(y_txt, header=None)

    train_df['y'] = y_appetency

    train_df = train_df.dropna()
    
#     clf = AdaBoostClassifier(DecisionTreeClassifier(max_depth=3),
#                              learning_rate=1.0,
#                              n_estimators=10,                             
#                              )

#     clf = GradientBoostingClassifier(n_estimators=10, 
#                                      learning_rate=1.0,
#                                      max_depth=3, 
#                                      random_state=0)
     
    clf = RandomForestClassifier(max_depth=3, 
                                 n_estimators=100, 
                                 max_features='auto',
                                 )

    clf.fit(train_df.ix[:, 0:-1], train_df.ix[:, -1])
    print(clf.score(train_df.ix[:, 0:-1], train_df.ix[:, -1]))
    return clf

if __name__ == "__main__":
    print('train accuracy_score:')
    clf_app = train('train.txt', 'train_label_appetency.txt')
    clf_chu = train('train.txt', 'train_label_churn.txt')
    clf_ups = train('train.txt', 'train_label_upselling.txt')
        
    with open('app.clf', 'w') as f:
        pickle.dump(clf_app, f) 
           
    with open('chu.clf', 'w') as f:
        pickle.dump(clf_chu, f)    
    
    with open('ups.clf', 'w') as f:
        pickle.dump(clf_ups, f)
            
    test_df = pd.read_csv('test.txt', header=None)
    test_df = test_df[index]
    test_df.fillna(0, inplace=True)

    test_y_app = pd.read_csv('test_label_appetency.txt', header=None)
    test_y_chu = pd.read_csv('test_label_churn.txt', header=None)
    test_y_ups = pd.read_csv('test_label_upselling.txt', header=None)

    print('test accuracy_score:')
    print(clf_app.score(test_df, test_y_app))
    print(clf_chu.score(test_df, test_y_chu))
    print(clf_ups.score(test_df, test_y_ups))
