﻿package preprocess;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class DataPreprocess {
	static int sum[] = new int[230];
	static int total = 0;

	public static String svfile = "conclusion.txt";
	public static String sstring = "";
	//保存字符串到文件中
	static void saveAsFileWriter(String content) {

	 FileWriter fwriter = null;
	 try {
	  fwriter = new FileWriter(svfile);
	  fwriter.write(content);
	 } catch (IOException ex) {
	  ex.printStackTrace();
	 } finally {
	  try {
	   fwriter.flush();
	   fwriter.close();
	  } catch (IOException ex) {
	   ex.printStackTrace();
	  }
	 }
	}


    static void read2(){
    	for (int i = 0;i<230;i++)
			sum[i]=0;
    	try {
    		String encoding="GBK";
    		File file=new File("train.txt");
    		if(file.isFile() && file.exists()){ //判断文件是否存在
    			InputStreamReader read = new InputStreamReader(new FileInputStream(file),encoding);//考虑到编码格式
    			BufferedReader bufferedReader = new BufferedReader(read);
    			String lineTxt = null;
    			while((lineTxt = bufferedReader.readLine()) != null){
    				total++;
    				String[] tempArray = lineTxt.split(",",230);
    		     	//System.out.println(tempArray.length);
    		     	for (int i=0;i<tempArray.length;i++){
    		     		//System.out.print(tempArray[i]+"+");
    		     		if (tempArray[i].isEmpty())
    		    			sum[i]+=1;
    		     	}
    		     	lineTxt=null;
    			}
    			read.close();
    			System.out.println();
    			int l= 0;
    			for (int i= 0;i<230;i++){
    				if (sum[i]<1500){
    					System.out.println(l +":" + i +"  frequency:" + sum[i]);
    					sstring +=(l++ +":" + i +"  frequency:" + sum[i]+"\r\n");
    				}
    			}
    			//saveAsFileWriter(sstring);
    			int [] s = sum;
    			Arrays.sort(s);
    			for (int i= 0;i<230;i++){
    				System.out.println(i+":"+s[i]);
    				//System.out.print("+");
    				}
    			System.out.println();
   		     System.out.println(total);
    		}else{
    			System.out.println("找不到指定的文件");
    		}
    	} catch (Exception e) {
    		System.out.println("读取文件内容出错");
    		e.printStackTrace();
    	}
	}

	public static void main(String[] agrs) throws IOException{

		read2();
	}

}
